<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "book_ordering";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (!$conn) {
    die("Connection failed:");
}
echo "successfully";

$sql="INSERT INTO register(firstname,lastname,username,phone,fpass,pass)VALUES('$_POST[firstname]','$_POST[lastname]','$_POST[username]','$_POST[phone]','$_POST[fpass]','$_POST[pass]')";


if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
  
} 
else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>